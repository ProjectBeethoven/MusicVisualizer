﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCamera : MonoBehaviour {
    // Use this for initialization
    float tempo = 3.5f;

	
	// Update is called once per frame
	void Update () {
        transform.position += Vector3.up * (Time.deltaTime*tempo);	
	}
}


//Source: https://answers.unity.com/questions/252614/moving-the-camera-up-and-down-by-pressing-key.html