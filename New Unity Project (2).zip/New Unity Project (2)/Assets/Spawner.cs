﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {
    [SerializeField]
    private GameObject note;
    [SerializeField]

    System.Random r = new System.Random();
	// Use this for initialization
	void Start()
    {
        for (int i = 0; i < 10; i++)
        {
            note.transform.localScale = new Vector3(.6f, i * 5, 0);
            //Instantiate(note, new Vector3(i *.25f, i *5 + 5, 0), Quaternion.identity);
            Instantiate(note, new Vector3((float)r.NextDouble() * 10f-5, (float)r.NextDouble() * 23f + 5, 0), Quaternion.identity);
        }
    }
}
