﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class loadscreenscript : MonoBehaviour {

    public void loadscreens(){
    SceneManager.LoadScene("LoadScreen");
    }
}
